function engineering_calculator()

% currently only handles the case of "number" "operation" "number"; numbers
% must exist between 0 and 9

% initial parameters for input variables
input1=nan;
operation1=nan;
input2=nan;

% creation of graphics for calculator
f = figure('color','[0 0.4470 0.7410]','Position',[100 100 600 400]);
zero = uicontrol(f, 'Style','pushbutton','String','0','Position',[20 20 250 50],...
    ...
    'Callback',@PushButton_zero);
one = uicontrol(f, 'Style','pushbutton','String','1','Position',[20 100 110 50],...
    ...
    'Callback',@PushButton_one);
two = uicontrol(f, 'Style','pushbutton','String','2','Position',[160 100 110 50],...
    ...
    'Callback',@PushButton_two);
three = uicontrol(f, 'Style','pushbutton','String','3','Position',[300 100 110 50],...
    ...
    'Callback',@PushButton_three);
four = uicontrol(f, 'Style','pushbutton','String','4','Position',[20 180 110 50],...
    ...
    'Callback',@PushButton_four);
five = uicontrol(f, 'Style','pushbutton','String','5','Position',[160 180 110 50],...
    ...
    'Callback',@PushButton_five);
six = uicontrol(f, 'Style','pushbutton','String','6','Position',[300 180 110 50],...
    ...
    'Callback',@PushButton_six);
seven = uicontrol(f, 'Style','pushbutton','String','7','Position',[20 260 110 50],...
    ...
    'Callback',@PushButton_seven);
eight = uicontrol(f, 'Style','pushbutton','String','8','Position',[160 260 110 50],...
    ...
    'Callback',@PushButton_eight);
nine = uicontrol(f, 'Style','pushbutton','String','9','Position',[300 260 110 50],...
    ...
    'Callback',@PushButton_nine);
equals = uicontrol(f, 'Style','pushbutton','String','=','Position',[440 20 110 50],...
    ...
    'Callback',@PushButton_equals);
addition = uicontrol(f, 'Style','pushbutton','String','+','Position',[440 100 110 50],...
    ...
    'Callback',@PushButton_addition);
subtraction = uicontrol(f, 'Style','pushbutton','String','-','Position',[440 180 110 50],...
    ...
    'Callback',@PushButton_subtraction);
multiplication = uicontrol(f, 'Style','pushbutton','String','x','Position',[440 260 110 50],...
    ...
    'Callback',@PushButton_multiplication);
division = uicontrol(f, 'Style','pushbutton','String','/','Position',[440 340 110 50],...
    ...
    'Callback',@PushButton_division);
clear = uicontrol(f, 'Style','pushbutton','String','Clear','Position',[20 340 110 50],...
    ...
    'Callback',@PushButton_clear);

% Button Function 0
    function PushButton_zero(Zero,b)
        disp('0') 
        if isnan(input1)
            input1 = 0;
        else input2 = 0;
        end
    end
 
% Button Function 1
    function PushButton_one(One,b)
        disp('1')
        if isnan(input1)
            disp(input1);
            input1 = 1;
        else input2 = 1;
        end
    end

% Button Function 2
    function PushButton_two(Two,b)
        disp('2')
        if isnan(input1)
            input1 = 2;
        else input2 = 2;
        end
    end

% Button Function 3
    function PushButton_three(Three,b)
        disp('3')
        if isnan(input1)
            input1 = 3;
        else input2 = 3;
        end
    end

% Button Function 4
    function PushButton_four(Four,b)
        disp('4')
        if isnan(input1)
            input1 = 4;
        else input2 = 4;
        end
    end

% Button Function 5
    function PushButton_five(Five,b)
        disp('5')
        if isnan(input1)
            input1 = 5;
        else input2 = 5;
        end
    end

% Button Function 6
    function PushButton_six(Six,b)
        disp('6')
        if isnan(input1)
            input1 = 6;
        else input2 = 6;
        end
    end

%Button Function 7
    function PushButton_seven(Seven,b)
        disp('7')
        if isnan(input1)
            input1 = 7;
        else input2 = 7;
        end
    end

% Button Function 8
    function PushButton_eight(Eight,b)
        disp('8')
        if isnan(input1)
            input1 = 8;
        else input2 = 8;
        end
    end

% Button Function 9
    function PushButton_nine(Nine,b)
        disp('9')
        if isnan(input1)
            input1 = 9;
        else input2 = 9;
        end
    end

% Button Function +
    function PushButton_addition(Addition,b)
        disp('+')
        operation1 = '+';
    end

% Button Function -
    function PushButton_subtraction(Subtraction,b)
        disp('-')
        operation1 = '-';
    end
% Button Function *
    function PushButton_multiplication(Multiplication,b)
        disp('*')
        operation1 = '*';
    end

% Button Function /
    function PushButton_division(Divison,b)
        disp('/')
        operation1 = '/';
    end
% Button Function clear
    function PushButton_clear(Clear,b)
        input1=nan;
        operation1=nan;
        input2=nan;
    end
% Button Function =
    function PushButton_equals(Equals,b)
        disp('=')
        disp(input1);
        disp(operation1);
        disp(input2);
        finalOutput = nan; % the output number variable 
        if operation1 == '+'
            finalOutput = input1 + input2;
        elseif operation1 == '-'
            finalOutput = input1 - input2;
        elseif operation1 == '*'
            finalOutput = input1 * input2;
        elseif operation1 == '/'
            finalOutput = input1 / input2;
        else %fail case
            disp("operation unknown")
        end
        disp(finalOutput)
        msgbox(num2str(input1)+" "+ operation1+" "+num2str(input2)+" "+"="+" "+num2str(finalOutput));
        
        % resets the input variables to original state
        input1=nan;
        operation1=nan;
        input2=nan;
    end
end